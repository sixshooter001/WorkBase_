﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml;


namespace WorkBase
{
    public partial class ImportForm : Form
    {
        public List<Cards> cards;
        public bool upload = false;
        public bool replace = false;
        public ImportForm()
        {
            InitializeComponent();

            UploadCheckBox.Checked = Properties.Settings.Default.upload;
            ReplaceCheckBox.Checked = Properties.Settings.Default.replace;
        }

        private void OpenFileButton_Click(object sender, EventArgs e) // Выбор файла
        {
            OpenFileDialog file_dialog = new OpenFileDialog();
            file_dialog.Filter = "XML Document|*.xml";

            if(file_dialog.ShowDialog() == DialogResult.OK)
            {
                InputFileText.Text = file_dialog.FileName;
                ImportButton.Enabled = true;
            }
        }

        private void ImportButton_Click(object sender, EventArgs e) // Импорт файла
        {
            upload = UploadCheckBox.Checked;
            replace = ReplaceCheckBox.Checked;

            cards = new List<Cards>();
            // Без загрузки на сервер
            XmlDocument xmlCards = new XmlDocument();
            xmlCards.Load(InputFileText.Text);
            XmlNodeList cardNodes = xmlCards.SelectNodes("//Cards/Card");
            foreach (XmlNode cardNode in cardNodes)
            {
                Cards card = new Cards();

                card.CardCode = cardNode.Attributes["CARDCODE"].Value;

                string _startdate = cardNode.Attributes["STARTDATE"].Value;
                if (_startdate != "")
                    card.StartDate = DateTime.Parse(_startdate);

                string _finishdate = cardNode.Attributes["FINISHDATE"].Value;
                if (_finishdate != "")
                    card.FinishDate = DateTime.Parse(_finishdate);

                card.LastName = cardNode.Attributes["LASTNAME"].Value;

                card.FirstName = cardNode.Attributes["FIRSTNAME"].Value;

                card.SurName = cardNode.Attributes["SURNAME"].Value;

                card.Gender = cardNode.Attributes["GENDERID"].Value;

                string _birthday = cardNode.Attributes["BIRTHDAY"].Value;
                if (_birthday != "")
                    card.Bithday = DateTime.Parse(_birthday);

                card.PhoneHome = cardNode.Attributes["PHONEHOME"].Value;

                card.PhoneMobile = cardNode.Attributes["PHONEMOBIL"].Value;

                card.Email = cardNode.Attributes["EMAIL"].Value;

                card.City = cardNode.Attributes["CITY"].Value;

                card.Street = cardNode.Attributes["STREET"].Value;

                card.House = cardNode.Attributes["HOUSE"].Value;

                card.Apartament = cardNode.Attributes["APARTMENT"].Value;
                card.Update = true;

                cards.Add(card);
            }

            Properties.Settings.Default.upload = UploadCheckBox.Checked;
            Properties.Settings.Default.replace = ReplaceCheckBox.Checked;
            Properties.Settings.Default.Save();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}

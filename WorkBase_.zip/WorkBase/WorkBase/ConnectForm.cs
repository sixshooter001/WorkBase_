﻿using System;
using System.Windows.Forms;

namespace WorkBase
{

    public partial class ConnectForm : Form
    {
        private MainWindow other;

        private bool _connectionState { get; set; }
        string _configPath = "config.xml";
        public ConnectForm(MainWindow other)
        {
            this.other = other;
            InitializeComponent();
        }


        private void ConnectForm_Load(object sender, EventArgs e) // Событие при открытии окна
        {
            _connectionState = DataBase.state();
            if (_connectionState)
                ConnectButton.Text = "Отключить";

            LoadData();
        }

        private void ConnectButton_Click(object sender, EventArgs e) // Событие при нажатии кнопки подключение
        {
            if (_connectionState) // Если уже подключено
            {
                DataBase.close();
                ConnectButton.Text = "Подключить";
                _connectionState = false;
                other.SetConnectionState(_connectionState);
            }
            else // Если нет подключения
            {
                string server = ServerTextBox.Text; // Название сервера
                string database = DataBaseTextBox.Text; // Название базы данных
                bool integratedSecurity = IntegratedSecurityCheckBox.Checked; // Комплексная безопасность
                DataBase.source(server, database, integratedSecurity);

                if (DataBase.connect()) // Подключение
                {
                    ConnectButton.Text = "Отключить";
                    _connectionState = true;
                    other.SetConnectionState(_connectionState);
                    SaveData();
                    this.Close();
                }
                else // Не удалось подключиться
                {
                    MessageBox.Show(
                        "Не удалось подключиться к серверу",
                        "Ошибка",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private void CheckTextBox(object sender, EventArgs e) // Метод проверки строк
        {
            if (!string.IsNullOrEmpty(ServerTextBox.Text) && !string.IsNullOrEmpty(DataBaseTextBox.Text))
                ConnectButton.Enabled = true;
            else
                ConnectButton.Enabled = false;
        }

        private void LoadData() // Загрузка сохраненных данных о базе
        {
            ServerTextBox.Text = Properties.Settings.Default.server; // Название сервера
            DataBaseTextBox.Text = Properties.Settings.Default.database; // Название базы данных
            IntegratedSecurityCheckBox.Checked = Properties.Settings.Default.integratedSecurity; // Комплексная безопасность
            SaveDataBaseCheckBox.Checked = Properties.Settings.Default.saved; // Сохранение базы данных
            AutoConnectCheckBox.Checked = Properties.Settings.Default.autoconnect; // Автоподключение при запуске
        }

        private void SaveData() // сохранение данных в базу
        {
            bool saved = SaveDataBaseCheckBox.Checked;// Сохранение базы данных
            Properties.Settings.Default.saved = saved; // Сохранение базы данных
            Properties.Settings.Default.autoconnect = AutoConnectCheckBox.Checked; // Автоподключение при запуске
            if (saved) // Галочка сохранить данные о подключении
            {
                Properties.Settings.Default.server = ServerTextBox.Text; // Название сервера
                Properties.Settings.Default.database = DataBaseTextBox.Text; // Название базы данных
                Properties.Settings.Default.integratedSecurity = IntegratedSecurityCheckBox.Checked; // Комплексная безопасность
            }
            Properties.Settings.Default.Save();
        }

        private void ApplyButton_Click(object sender, EventArgs e) // Кнопка применить
        {
            SaveData();
        }
    }
}

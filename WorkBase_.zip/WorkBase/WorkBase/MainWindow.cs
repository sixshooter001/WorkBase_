﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkBase
{
    public partial class MainWindow : Form
    {
        List<Cards> cards = new List<Cards>();
        public MainWindow()
        {
            InitializeComponent();
        }


        private void ConnectToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка подключить
        {
            // Открывает окно подключения
            ConnectForm connectForm = new ConnectForm(this);
            connectForm.ShowDialog();
        }

        private void ImportXMLToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка импорт
        {
            // Открывает окно импорта
            ImportForm importForm = new ImportForm();
            if (importForm.ShowDialog() != DialogResult.OK)
                return;

            // Загружает данные с xml файл в виде объекта Cards
            List<Cards> xmlcards = importForm.cards;

            if (importForm.upload) // проверка галочки загрузить сразу
            {
                if (DataBase.state()) // проверка подключения к базе данных
                    DataBase.upload(xmlcards, importForm.replace); // Загрузка данных в базу (база, замена)
            }
               

            foreach (Cards card in xmlcards) 
            {
                int id = cards.FindIndex(x => x.CardCode == card.CardCode); // Получение index по CARDCODE
                string fullname = $"{card.LastName} {card.FirstName} {card.SurName}";// FullName
                if (id > -1) // Найден элемент
                {
                    if (importForm.replace) // замена
                    {
                        if(!importForm.upload) // проверка галочки загрузить сразу
                            card.Update = true; // Данные нужно загрузить
                        else
                            card.Update = false; // Данные не нужно загружать на сервер
                        cards[id] = card;
                    }
                    
                }
                else
                {
                    if (!importForm.upload) // проверка галочки загрузить сразу
                        card.Update = true; // Данные нужно загрузить
                    else
                        card.Update = false; // Данные не нужно загружать на сервер
                    cards.Add(card);
                }
                
            }
            refresh(false);


        }

        private void MainWindow_Load(object sender, EventArgs e) // Событие загрузки ПО
        {
            string server = Properties.Settings.Default.server;
            string database = Properties.Settings.Default.database;
            bool integratedSecurity = Properties.Settings.Default.integratedSecurity;
            bool auto_connect = Properties.Settings.Default.autoconnect;
            if (auto_connect)
            {
                DataBase.source(server, database, integratedSecurity);
                if (DataBase.connect())
                {
                    SetConnectionState(true);
                    refresh();
                }
                else
                {
                    SetConnectionState(false);
                    MessageBox.Show(
                           "Не удалось подключиться к серверу",
                           "Ошибка",
                           MessageBoxButtons.OK,
                           MessageBoxIcon.Error);
                }

            }
        }

        public void SetConnectionState(bool state) // Метод статус 
        {
            if (state)
            {
                ConnectedStateLabel.Text = "Подключен!";
                ConnectedStateLabel.ForeColor = Color.Green;
            }
            else
            {
                ConnectedStateLabel.Text = "Не подключен";
                ConnectedStateLabel.ForeColor = Color.Red;
            }
        }

        private void QuitToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка выход
        {
            Application.Exit();
        }

        private void MainWindow_FormClosing(object sender, FormClosingEventArgs e) // Событие выхода из ПО
        {
            DataBase.close();
        }

        private void FinndButton_Click(object sender, EventArgs e) // Кнопка поиска элемента
        {
            ClientsListView.Items.Clear();
            List<Cards> find = cards.FindAll(x => x.CardCode.Contains(FindTextBox.Text) || $"{x.LastName} {x.FirstName} {x.SurName}".ToLower().Contains(FindTextBox.Text.ToLower()));
            foreach (Cards card in find)
            {
                string fullname = $"{card.LastName} {card.FirstName} {card.SurName}";
                ListViewItem item = new ListViewItem();
                if(card.Update == true)
                    item.BackColor = Color.FromArgb(255, 255, 153);
                item.Text = fullname;
                item.SubItems.Add(card.CardCode);
                if (card.StartDate != DateTime.MinValue)
                    item.SubItems.Add(card.StartDate.ToString("yyyy'-'MM'-'dd"));
                else
                    item.SubItems.Add("");

                if (card.FinishDate != DateTime.MinValue)
                    item.SubItems.Add(card.FinishDate.ToString("yyyy'-'MM'-'dd"));
                else
                    item.SubItems.Add("");
                ClientsListView.Items.Add(item);
            }
        }

        private void ClientsListView_DoubleClick(object sender, EventArgs e) // Двойной клик Список
        {
            edit();
        }

        private void UploadButton_Click(object sender, EventArgs e) // Кнопка загрузки данных на сервер
        {
            if (DataBase.state())
            {
                DataBase.upload(cards);

                cards = DataBase.load();
                refresh();
            }
            
        }

        private void refresh(bool reload = true) // Метод обновления
        {
            if (DataBase.state())
            {
                ClientsListView.Items.Clear();
                if(reload)
                    cards = DataBase.load();

                foreach (Cards card in cards)
                {
                    string fullname = $"{card.LastName} {card.FirstName} {card.SurName}";
                    ListViewItem item = new ListViewItem();
                    if (card.Update)
                        item.BackColor = Color.FromArgb(255, 255, 153);
                    item.Text = fullname;
                    item.SubItems.Add(card.CardCode);
                    if (card.StartDate != DateTime.MinValue)
                        item.SubItems.Add(card.StartDate.ToString("yyyy'-'MM'-'dd"));
                    else
                        item.SubItems.Add("");

                    if (card.FinishDate != DateTime.MinValue)
                        item.SubItems.Add(card.FinishDate.ToString("yyyy'-'MM'-'dd"));
                    else
                        item.SubItems.Add("");
                    ClientsListView.Items.Add(item);
                }
            }
            
        }

        private void edit() // Метод редактирования
        {
            
            if (ClientsListView.SelectedIndices.Count > 0)
            {
                int select_index = ClientsListView.SelectedIndices[0];
                ListViewItem item = ClientsListView.Items[select_index];
                int id = cards.FindIndex(x => x.CardCode == item.SubItems[1].Text);
                CardEditForm cardform = new CardEditForm(cards[id]);
                if (cardform.ShowDialog() == DialogResult.OK)
                {
                    Cards edit_card = cardform.card;
                    edit_card.Update = true;
                    cards[id] = edit_card;
                    item.Text = $"{edit_card.LastName} {edit_card.FirstName} {edit_card.SurName}";
                    item.SubItems[1].Text = edit_card.CardCode;
                    if (edit_card.StartDate != DateTime.MinValue)
                        item.SubItems[2].Text = edit_card.StartDate.ToString("yyyy'-'MM'-'dd");
                    else
                        item.SubItems[2].Text = "";

                    if (edit_card.FinishDate != DateTime.MinValue)
                        item.SubItems[3].Text = edit_card.FinishDate.ToString("yyyy'-'MM'-'dd");
                    else
                        item.SubItems[3].Text = "";
                    item.BackColor = Color.FromArgb(255, 255, 153);
                }
            }
        }

        private void RefreshToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка обновить
        {
            refresh();
        }

        private void EditToolStripMenuItem_Click(object sender, EventArgs e) // Кнопка изменить
        {
            edit();
        }

        private void ClientContextMenuStrip_Opening(object sender, CancelEventArgs e) // Проверка выбора элемента
        {
            if (ClientsListView.SelectedIndices.Count > 0)
                EditToolStripMenuItem.Enabled= true;
            else
                EditToolStripMenuItem.Enabled = false;
        }

        private void ReloadToolStripMenuItem_Click(object sender, EventArgs e) // данные
        {
            refresh(false);
        }

        private void ReloadDDBToolStripMenuItem_Click(object sender, EventArgs e) // Обновить данные с базы
        {
            refresh(true);
        }

        private void AboutToolStripMenuItem1_Click(object sender, EventArgs e) // Кнопка о программе
        {
            AboutForm aboutform = new AboutForm();
            aboutform.ShowDialog();
        }
    }
}

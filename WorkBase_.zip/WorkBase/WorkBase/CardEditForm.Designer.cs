﻿namespace WorkBase
{
    partial class CardEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CityLabel = new System.Windows.Forms.Label();
            this.CityText = new System.Windows.Forms.TextBox();
            this.ApartamentLabel = new System.Windows.Forms.Label();
            this.ApartamentText = new System.Windows.Forms.TextBox();
            this.HomeLabel = new System.Windows.Forms.Label();
            this.HouseText = new System.Windows.Forms.TextBox();
            this.StreetLabel = new System.Windows.Forms.Label();
            this.StreetText = new System.Windows.Forms.TextBox();
            this.PeopleGroupBox = new System.Windows.Forms.GroupBox();
            this.BirthDayPicker = new System.Windows.Forms.DateTimePicker();
            this.BirthdayLabel = new System.Windows.Forms.Label();
            this.GenderComboBox = new System.Windows.Forms.ComboBox();
            this.GenderLabel = new System.Windows.Forms.Label();
            this.SurnameLabel = new System.Windows.Forms.Label();
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.SurnameText = new System.Windows.Forms.TextBox();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.FirstNameText = new System.Windows.Forms.TextBox();
            this.LastNameText = new System.Windows.Forms.TextBox();
            this.ContactGroupBox = new System.Windows.Forms.GroupBox();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.PhoneMobileText = new System.Windows.Forms.TextBox();
            this.EmailText = new System.Windows.Forms.TextBox();
            this.PhoneHomeText = new System.Windows.Forms.TextBox();
            this.PhoneMobileLabel = new System.Windows.Forms.Label();
            this.PhoneHomeLabel = new System.Windows.Forms.Label();
            this.AddressGroupBox = new System.Windows.Forms.GroupBox();
            this.CardGroupBox = new System.Windows.Forms.GroupBox();
            this.CardCodeText = new System.Windows.Forms.TextBox();
            this.FinishDatePicker = new System.Windows.Forms.DateTimePicker();
            this.CardCodeLabel = new System.Windows.Forms.Label();
            this.StartDatePicker = new System.Windows.Forms.DateTimePicker();
            this.StartDateLabel = new System.Windows.Forms.Label();
            this.FinishDateLabel = new System.Windows.Forms.Label();
            this.ApplyButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.PeopleGroupBox.SuspendLayout();
            this.ContactGroupBox.SuspendLayout();
            this.AddressGroupBox.SuspendLayout();
            this.CardGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // CityLabel
            // 
            this.CityLabel.AutoSize = true;
            this.CityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CityLabel.Location = new System.Drawing.Point(31, 27);
            this.CityLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CityLabel.Name = "CityLabel";
            this.CityLabel.Size = new System.Drawing.Size(61, 20);
            this.CityLabel.TabIndex = 22;
            this.CityLabel.Text = "Город";
            // 
            // CityText
            // 
            this.CityText.BackColor = System.Drawing.Color.White;
            this.CityText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CityText.Location = new System.Drawing.Point(19, 50);
            this.CityText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CityText.Name = "CityText";
            this.CityText.Size = new System.Drawing.Size(279, 30);
            this.CityText.TabIndex = 21;
            this.CityText.TextChanged += new System.EventHandler(this.CityText_TextChanged);
            // 
            // ApartamentLabel
            // 
            this.ApartamentLabel.AutoSize = true;
            this.ApartamentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ApartamentLabel.Location = new System.Drawing.Point(31, 204);
            this.ApartamentLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ApartamentLabel.Name = "ApartamentLabel";
            this.ApartamentLabel.Size = new System.Drawing.Size(125, 20);
            this.ApartamentLabel.TabIndex = 28;
            this.ApartamentLabel.Text = "Апартаменты";
            this.ApartamentLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ApartamentText
            // 
            this.ApartamentText.BackColor = System.Drawing.Color.White;
            this.ApartamentText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ApartamentText.Location = new System.Drawing.Point(19, 228);
            this.ApartamentText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ApartamentText.Name = "ApartamentText";
            this.ApartamentText.Size = new System.Drawing.Size(279, 30);
            this.ApartamentText.TabIndex = 27;
            this.ApartamentText.TextChanged += new System.EventHandler(this.ApartamentText_TextChanged);
            // 
            // HomeLabel
            // 
            this.HomeLabel.AutoSize = true;
            this.HomeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HomeLabel.Location = new System.Drawing.Point(31, 145);
            this.HomeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.HomeLabel.Name = "HomeLabel";
            this.HomeLabel.Size = new System.Drawing.Size(44, 20);
            this.HomeLabel.TabIndex = 26;
            this.HomeLabel.Text = "Дом";
            // 
            // HouseText
            // 
            this.HouseText.BackColor = System.Drawing.Color.White;
            this.HouseText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HouseText.Location = new System.Drawing.Point(19, 169);
            this.HouseText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.HouseText.Name = "HouseText";
            this.HouseText.Size = new System.Drawing.Size(279, 30);
            this.HouseText.TabIndex = 25;
            this.HouseText.TextChanged += new System.EventHandler(this.HouseText_TextChanged);
            // 
            // StreetLabel
            // 
            this.StreetLabel.AutoSize = true;
            this.StreetLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StreetLabel.Location = new System.Drawing.Point(31, 86);
            this.StreetLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.StreetLabel.Name = "StreetLabel";
            this.StreetLabel.Size = new System.Drawing.Size(60, 20);
            this.StreetLabel.TabIndex = 24;
            this.StreetLabel.Text = "Улица";
            // 
            // StreetText
            // 
            this.StreetText.BackColor = System.Drawing.Color.White;
            this.StreetText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StreetText.Location = new System.Drawing.Point(19, 110);
            this.StreetText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.StreetText.Name = "StreetText";
            this.StreetText.Size = new System.Drawing.Size(279, 30);
            this.StreetText.TabIndex = 23;
            this.StreetText.TextChanged += new System.EventHandler(this.StreetText_TextChanged);
            // 
            // PeopleGroupBox
            // 
            this.PeopleGroupBox.Controls.Add(this.BirthDayPicker);
            this.PeopleGroupBox.Controls.Add(this.BirthdayLabel);
            this.PeopleGroupBox.Controls.Add(this.GenderComboBox);
            this.PeopleGroupBox.Controls.Add(this.GenderLabel);
            this.PeopleGroupBox.Controls.Add(this.SurnameLabel);
            this.PeopleGroupBox.Controls.Add(this.FirstNameLabel);
            this.PeopleGroupBox.Controls.Add(this.SurnameText);
            this.PeopleGroupBox.Controls.Add(this.LastNameLabel);
            this.PeopleGroupBox.Controls.Add(this.FirstNameText);
            this.PeopleGroupBox.Controls.Add(this.LastNameText);
            this.PeopleGroupBox.Location = new System.Drawing.Point(16, 15);
            this.PeopleGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.PeopleGroupBox.Name = "PeopleGroupBox";
            this.PeopleGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.PeopleGroupBox.Size = new System.Drawing.Size(317, 316);
            this.PeopleGroupBox.TabIndex = 39;
            this.PeopleGroupBox.TabStop = false;
            this.PeopleGroupBox.Text = "Личность";
            // 
            // BirthDayPicker
            // 
            this.BirthDayPicker.Location = new System.Drawing.Point(19, 270);
            this.BirthDayPicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BirthDayPicker.Name = "BirthDayPicker";
            this.BirthDayPicker.Size = new System.Drawing.Size(279, 22);
            this.BirthDayPicker.TabIndex = 41;
            this.BirthDayPicker.ValueChanged += new System.EventHandler(this.BirthDayPicker_ValueChanged);
            // 
            // BirthdayLabel
            // 
            this.BirthdayLabel.AutoSize = true;
            this.BirthdayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BirthdayLabel.Location = new System.Drawing.Point(31, 245);
            this.BirthdayLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BirthdayLabel.Name = "BirthdayLabel";
            this.BirthdayLabel.Size = new System.Drawing.Size(141, 20);
            this.BirthdayLabel.TabIndex = 40;
            this.BirthdayLabel.Text = "Дата рождения";
            // 
            // GenderComboBox
            // 
            this.GenderComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.GenderComboBox.FormattingEnabled = true;
            this.GenderComboBox.Items.AddRange(new object[] {
            "Мужской",
            "Женский"});
            this.GenderComboBox.Location = new System.Drawing.Point(19, 219);
            this.GenderComboBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.GenderComboBox.Name = "GenderComboBox";
            this.GenderComboBox.Size = new System.Drawing.Size(279, 24);
            this.GenderComboBox.TabIndex = 41;
            this.GenderComboBox.SelectedIndexChanged += new System.EventHandler(this.GenderComboBox_SelectedIndexChanged);
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GenderLabel.Location = new System.Drawing.Point(31, 196);
            this.GenderLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(42, 20);
            this.GenderLabel.TabIndex = 40;
            this.GenderLabel.Text = "Пол";
            // 
            // SurnameLabel
            // 
            this.SurnameLabel.AutoSize = true;
            this.SurnameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SurnameLabel.Location = new System.Drawing.Point(31, 140);
            this.SurnameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SurnameLabel.Name = "SurnameLabel";
            this.SurnameLabel.Size = new System.Drawing.Size(91, 20);
            this.SurnameLabel.TabIndex = 41;
            this.SurnameLabel.Text = "Отчество";
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FirstNameLabel.Location = new System.Drawing.Point(31, 81);
            this.FirstNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(42, 20);
            this.FirstNameLabel.TabIndex = 41;
            this.FirstNameLabel.Text = "Имя";
            // 
            // SurnameText
            // 
            this.SurnameText.BackColor = System.Drawing.Color.White;
            this.SurnameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SurnameText.Location = new System.Drawing.Point(19, 164);
            this.SurnameText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SurnameText.Name = "SurnameText";
            this.SurnameText.Size = new System.Drawing.Size(279, 30);
            this.SurnameText.TabIndex = 40;
            this.SurnameText.TextChanged += new System.EventHandler(this.SurnameText_TextChanged);
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LastNameLabel.Location = new System.Drawing.Point(31, 23);
            this.LastNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(87, 20);
            this.LastNameLabel.TabIndex = 41;
            this.LastNameLabel.Text = "Фамилия";
            // 
            // FirstNameText
            // 
            this.FirstNameText.BackColor = System.Drawing.Color.White;
            this.FirstNameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FirstNameText.Location = new System.Drawing.Point(19, 105);
            this.FirstNameText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FirstNameText.Name = "FirstNameText";
            this.FirstNameText.Size = new System.Drawing.Size(279, 30);
            this.FirstNameText.TabIndex = 40;
            this.FirstNameText.TextChanged += new System.EventHandler(this.FirstNameText_TextChanged);
            // 
            // LastNameText
            // 
            this.LastNameText.BackColor = System.Drawing.Color.White;
            this.LastNameText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LastNameText.Location = new System.Drawing.Point(19, 47);
            this.LastNameText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.LastNameText.Name = "LastNameText";
            this.LastNameText.Size = new System.Drawing.Size(279, 30);
            this.LastNameText.TabIndex = 40;
            this.LastNameText.TextChanged += new System.EventHandler(this.LastNameText_TextChanged);
            // 
            // ContactGroupBox
            // 
            this.ContactGroupBox.Controls.Add(this.EmailLabel);
            this.ContactGroupBox.Controls.Add(this.PhoneMobileText);
            this.ContactGroupBox.Controls.Add(this.EmailText);
            this.ContactGroupBox.Controls.Add(this.PhoneHomeText);
            this.ContactGroupBox.Controls.Add(this.PhoneMobileLabel);
            this.ContactGroupBox.Controls.Add(this.PhoneHomeLabel);
            this.ContactGroupBox.Location = new System.Drawing.Point(16, 338);
            this.ContactGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ContactGroupBox.Name = "ContactGroupBox";
            this.ContactGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ContactGroupBox.Size = new System.Drawing.Size(317, 226);
            this.ContactGroupBox.TabIndex = 40;
            this.ContactGroupBox.TabStop = false;
            this.ContactGroupBox.Text = "Контакты";
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EmailLabel.Location = new System.Drawing.Point(31, 143);
            this.EmailLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(179, 20);
            this.EmailLabel.TabIndex = 46;
            this.EmailLabel.Text = "Электронный адрес";
            // 
            // PhoneMobileText
            // 
            this.PhoneMobileText.BackColor = System.Drawing.Color.White;
            this.PhoneMobileText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PhoneMobileText.Location = new System.Drawing.Point(19, 110);
            this.PhoneMobileText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.PhoneMobileText.Name = "PhoneMobileText";
            this.PhoneMobileText.Size = new System.Drawing.Size(279, 30);
            this.PhoneMobileText.TabIndex = 43;
            this.PhoneMobileText.TextChanged += new System.EventHandler(this.PhoneMobileText_TextChanged);
            // 
            // EmailText
            // 
            this.EmailText.BackColor = System.Drawing.Color.White;
            this.EmailText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EmailText.Location = new System.Drawing.Point(19, 166);
            this.EmailText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EmailText.Name = "EmailText";
            this.EmailText.Size = new System.Drawing.Size(279, 30);
            this.EmailText.TabIndex = 45;
            this.EmailText.TextChanged += new System.EventHandler(this.EmailText_TextChanged);
            // 
            // PhoneHomeText
            // 
            this.PhoneHomeText.BackColor = System.Drawing.Color.White;
            this.PhoneHomeText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PhoneHomeText.Location = new System.Drawing.Point(19, 52);
            this.PhoneHomeText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.PhoneHomeText.Name = "PhoneHomeText";
            this.PhoneHomeText.Size = new System.Drawing.Size(279, 30);
            this.PhoneHomeText.TabIndex = 41;
            this.PhoneHomeText.TextChanged += new System.EventHandler(this.PhoneHomeText_TextChanged);
            // 
            // PhoneMobileLabel
            // 
            this.PhoneMobileLabel.AutoSize = true;
            this.PhoneMobileLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PhoneMobileLabel.Location = new System.Drawing.Point(31, 86);
            this.PhoneMobileLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PhoneMobileLabel.Name = "PhoneMobileLabel";
            this.PhoneMobileLabel.Size = new System.Drawing.Size(162, 20);
            this.PhoneMobileLabel.TabIndex = 44;
            this.PhoneMobileLabel.Text = "Мобильный номер";
            // 
            // PhoneHomeLabel
            // 
            this.PhoneHomeLabel.AutoSize = true;
            this.PhoneHomeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PhoneHomeLabel.Location = new System.Drawing.Point(31, 28);
            this.PhoneHomeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PhoneHomeLabel.Name = "PhoneHomeLabel";
            this.PhoneHomeLabel.Size = new System.Drawing.Size(155, 20);
            this.PhoneHomeLabel.TabIndex = 42;
            this.PhoneHomeLabel.Text = "Домашний номер";
            // 
            // AddressGroupBox
            // 
            this.AddressGroupBox.Controls.Add(this.StreetText);
            this.AddressGroupBox.Controls.Add(this.CityText);
            this.AddressGroupBox.Controls.Add(this.CityLabel);
            this.AddressGroupBox.Controls.Add(this.StreetLabel);
            this.AddressGroupBox.Controls.Add(this.HouseText);
            this.AddressGroupBox.Controls.Add(this.HomeLabel);
            this.AddressGroupBox.Controls.Add(this.ApartamentText);
            this.AddressGroupBox.Controls.Add(this.ApartamentLabel);
            this.AddressGroupBox.Location = new System.Drawing.Point(341, 15);
            this.AddressGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddressGroupBox.Name = "AddressGroupBox";
            this.AddressGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddressGroupBox.Size = new System.Drawing.Size(317, 277);
            this.AddressGroupBox.TabIndex = 41;
            this.AddressGroupBox.TabStop = false;
            this.AddressGroupBox.Text = "Адрес";
            // 
            // CardGroupBox
            // 
            this.CardGroupBox.Controls.Add(this.CardCodeText);
            this.CardGroupBox.Controls.Add(this.FinishDatePicker);
            this.CardGroupBox.Controls.Add(this.CardCodeLabel);
            this.CardGroupBox.Controls.Add(this.StartDatePicker);
            this.CardGroupBox.Controls.Add(this.StartDateLabel);
            this.CardGroupBox.Controls.Add(this.FinishDateLabel);
            this.CardGroupBox.Location = new System.Drawing.Point(341, 300);
            this.CardGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CardGroupBox.Name = "CardGroupBox";
            this.CardGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CardGroupBox.Size = new System.Drawing.Size(317, 201);
            this.CardGroupBox.TabIndex = 42;
            this.CardGroupBox.TabStop = false;
            this.CardGroupBox.Text = "Карта";
            // 
            // CardCodeText
            // 
            this.CardCodeText.BackColor = System.Drawing.Color.White;
            this.CardCodeText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CardCodeText.Location = new System.Drawing.Point(19, 48);
            this.CardCodeText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CardCodeText.Name = "CardCodeText";
            this.CardCodeText.Size = new System.Drawing.Size(279, 30);
            this.CardCodeText.TabIndex = 48;
            this.CardCodeText.TextChanged += new System.EventHandler(this.CardCodeText_TextChanged);
            // 
            // FinishDatePicker
            // 
            this.FinishDatePicker.Location = new System.Drawing.Point(19, 159);
            this.FinishDatePicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FinishDatePicker.Name = "FinishDatePicker";
            this.FinishDatePicker.Size = new System.Drawing.Size(279, 22);
            this.FinishDatePicker.TabIndex = 47;
            this.FinishDatePicker.ValueChanged += new System.EventHandler(this.FinishDatePicker_ValueChanged);
            // 
            // CardCodeLabel
            // 
            this.CardCodeLabel.AutoSize = true;
            this.CardCodeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CardCodeLabel.Location = new System.Drawing.Point(31, 26);
            this.CardCodeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CardCodeLabel.Name = "CardCodeLabel";
            this.CardCodeLabel.Size = new System.Drawing.Size(120, 20);
            this.CardCodeLabel.TabIndex = 43;
            this.CardCodeLabel.Text = "Номер карты";
            // 
            // StartDatePicker
            // 
            this.StartDatePicker.Location = new System.Drawing.Point(19, 105);
            this.StartDatePicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.StartDatePicker.Name = "StartDatePicker";
            this.StartDatePicker.Size = new System.Drawing.Size(279, 22);
            this.StartDatePicker.TabIndex = 46;
            this.StartDatePicker.ValueChanged += new System.EventHandler(this.StartDatePicker_ValueChanged);
            // 
            // StartDateLabel
            // 
            this.StartDateLabel.AutoSize = true;
            this.StartDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StartDateLabel.Location = new System.Drawing.Point(31, 81);
            this.StartDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.StartDateLabel.Name = "StartDateLabel";
            this.StartDateLabel.Size = new System.Drawing.Size(117, 20);
            this.StartDateLabel.TabIndex = 44;
            this.StartDateLabel.Text = "Дата начало";
            // 
            // FinishDateLabel
            // 
            this.FinishDateLabel.AutoSize = true;
            this.FinishDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FinishDateLabel.Location = new System.Drawing.Point(31, 133);
            this.FinishDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.FinishDateLabel.Name = "FinishDateLabel";
            this.FinishDateLabel.Size = new System.Drawing.Size(106, 20);
            this.FinishDateLabel.TabIndex = 45;
            this.FinishDateLabel.Text = "Дата конца";
            // 
            // ApplyButton
            // 
            this.ApplyButton.Location = new System.Drawing.Point(376, 526);
            this.ApplyButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ApplyButton.Name = "ApplyButton";
            this.ApplyButton.Size = new System.Drawing.Size(128, 39);
            this.ApplyButton.TabIndex = 43;
            this.ApplyButton.Text = "Изменить";
            this.ApplyButton.UseVisualStyleBackColor = true;
            this.ApplyButton.Click += new System.EventHandler(this.ApplyButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(512, 526);
            this.CancelButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(128, 39);
            this.CancelButton.TabIndex = 44;
            this.CancelButton.Text = "Отменить";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // CardEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 592);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.ApplyButton);
            this.Controls.Add(this.CardGroupBox);
            this.Controls.Add(this.AddressGroupBox);
            this.Controls.Add(this.ContactGroupBox);
            this.Controls.Add(this.PeopleGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "CardEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Редактор клиента";
            this.Load += new System.EventHandler(this.CardEditForm_Load);
            this.PeopleGroupBox.ResumeLayout(false);
            this.PeopleGroupBox.PerformLayout();
            this.ContactGroupBox.ResumeLayout(false);
            this.ContactGroupBox.PerformLayout();
            this.AddressGroupBox.ResumeLayout(false);
            this.AddressGroupBox.PerformLayout();
            this.CardGroupBox.ResumeLayout(false);
            this.CardGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label CityLabel;
        private System.Windows.Forms.TextBox CityText;
        private System.Windows.Forms.Label ApartamentLabel;
        private System.Windows.Forms.TextBox ApartamentText;
        private System.Windows.Forms.Label HomeLabel;
        private System.Windows.Forms.TextBox HouseText;
        private System.Windows.Forms.Label StreetLabel;
        private System.Windows.Forms.TextBox StreetText;
        private System.Windows.Forms.GroupBox PeopleGroupBox;
        private System.Windows.Forms.DateTimePicker BirthDayPicker;
        private System.Windows.Forms.Label BirthdayLabel;
        private System.Windows.Forms.ComboBox GenderComboBox;
        private System.Windows.Forms.Label GenderLabel;
        private System.Windows.Forms.Label SurnameLabel;
        private System.Windows.Forms.Label FirstNameLabel;
        private System.Windows.Forms.TextBox SurnameText;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.TextBox FirstNameText;
        private System.Windows.Forms.TextBox LastNameText;
        private System.Windows.Forms.GroupBox ContactGroupBox;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.TextBox PhoneMobileText;
        private System.Windows.Forms.TextBox EmailText;
        private System.Windows.Forms.TextBox PhoneHomeText;
        private System.Windows.Forms.Label PhoneMobileLabel;
        private System.Windows.Forms.Label PhoneHomeLabel;
        private System.Windows.Forms.GroupBox AddressGroupBox;
        private System.Windows.Forms.GroupBox CardGroupBox;
        private System.Windows.Forms.TextBox CardCodeText;
        private System.Windows.Forms.DateTimePicker FinishDatePicker;
        private System.Windows.Forms.Label CardCodeLabel;
        private System.Windows.Forms.DateTimePicker StartDatePicker;
        private System.Windows.Forms.Label StartDateLabel;
        private System.Windows.Forms.Label FinishDateLabel;
        private System.Windows.Forms.Button ApplyButton;
        private System.Windows.Forms.Button CancelButton;
    }
}
﻿namespace WorkBase
{
    partial class ConnectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ServerTextBox = new System.Windows.Forms.TextBox();
            this.ServerLabel = new System.Windows.Forms.Label();
            this.DateBaseLabel = new System.Windows.Forms.Label();
            this.DataBaseTextBox = new System.Windows.Forms.TextBox();
            this.ConnectButton = new System.Windows.Forms.Button();
            this.IntegratedSecurityCheckBox = new System.Windows.Forms.CheckBox();
            this.SaveDataBaseCheckBox = new System.Windows.Forms.CheckBox();
            this.AutoConnectCheckBox = new System.Windows.Forms.CheckBox();
            this.ApplyButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ServerTextBox
            // 
            this.ServerTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ServerTextBox.Location = new System.Drawing.Point(12, 39);
            this.ServerTextBox.Name = "ServerTextBox";
            this.ServerTextBox.Size = new System.Drawing.Size(273, 26);
            this.ServerTextBox.TabIndex = 0;
            this.ServerTextBox.TextChanged += new System.EventHandler(this.CheckTextBox);
            // 
            // ServerLabel
            // 
            this.ServerLabel.AutoSize = true;
            this.ServerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ServerLabel.Location = new System.Drawing.Point(21, 20);
            this.ServerLabel.Name = "ServerLabel";
            this.ServerLabel.Size = new System.Drawing.Size(131, 16);
            this.ServerLabel.TabIndex = 1;
            this.ServerLabel.Text = "Название сервера";
            // 
            // DateBaseLabel
            // 
            this.DateBaseLabel.AutoSize = true;
            this.DateBaseLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DateBaseLabel.Location = new System.Drawing.Point(21, 78);
            this.DateBaseLabel.Name = "DateBaseLabel";
            this.DateBaseLabel.Size = new System.Drawing.Size(159, 16);
            this.DateBaseLabel.TabIndex = 3;
            this.DateBaseLabel.Text = "Название базы данных";
            // 
            // DataBaseTextBox
            // 
            this.DataBaseTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DataBaseTextBox.Location = new System.Drawing.Point(12, 97);
            this.DataBaseTextBox.Name = "DataBaseTextBox";
            this.DataBaseTextBox.Size = new System.Drawing.Size(273, 26);
            this.DataBaseTextBox.TabIndex = 2;
            this.DataBaseTextBox.TextChanged += new System.EventHandler(this.CheckTextBox);
            // 
            // ConnectButton
            // 
            this.ConnectButton.Enabled = false;
            this.ConnectButton.Location = new System.Drawing.Point(12, 224);
            this.ConnectButton.Name = "ConnectButton";
            this.ConnectButton.Size = new System.Drawing.Size(112, 32);
            this.ConnectButton.TabIndex = 6;
            this.ConnectButton.Text = "Подключить";
            this.ConnectButton.UseVisualStyleBackColor = true;
            this.ConnectButton.Click += new System.EventHandler(this.ConnectButton_Click);
            // 
            // IntegratedSecurityCheckBox
            // 
            this.IntegratedSecurityCheckBox.AutoSize = true;
            this.IntegratedSecurityCheckBox.Checked = true;
            this.IntegratedSecurityCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.IntegratedSecurityCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.IntegratedSecurityCheckBox.Location = new System.Drawing.Point(12, 129);
            this.IntegratedSecurityCheckBox.Name = "IntegratedSecurityCheckBox";
            this.IntegratedSecurityCheckBox.Size = new System.Drawing.Size(137, 20);
            this.IntegratedSecurityCheckBox.TabIndex = 7;
            this.IntegratedSecurityCheckBox.Text = "Integrated Security";
            this.IntegratedSecurityCheckBox.UseVisualStyleBackColor = true;
            // 
            // SaveDataBaseCheckBox
            // 
            this.SaveDataBaseCheckBox.AutoSize = true;
            this.SaveDataBaseCheckBox.Checked = true;
            this.SaveDataBaseCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.SaveDataBaseCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SaveDataBaseCheckBox.Location = new System.Drawing.Point(12, 167);
            this.SaveDataBaseCheckBox.Name = "SaveDataBaseCheckBox";
            this.SaveDataBaseCheckBox.Size = new System.Drawing.Size(180, 20);
            this.SaveDataBaseCheckBox.TabIndex = 8;
            this.SaveDataBaseCheckBox.Text = "Сохранить базу данных";
            this.SaveDataBaseCheckBox.UseVisualStyleBackColor = true;
            // 
            // AutoConnectCheckBox
            // 
            this.AutoConnectCheckBox.AutoSize = true;
            this.AutoConnectCheckBox.Checked = true;
            this.AutoConnectCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoConnectCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AutoConnectCheckBox.Location = new System.Drawing.Point(12, 191);
            this.AutoConnectCheckBox.Name = "AutoConnectCheckBox";
            this.AutoConnectCheckBox.Size = new System.Drawing.Size(231, 20);
            this.AutoConnectCheckBox.TabIndex = 9;
            this.AutoConnectCheckBox.Text = "Автоподключение при запуске";
            this.AutoConnectCheckBox.UseVisualStyleBackColor = true;
            // 
            // ApplyButton
            // 
            this.ApplyButton.Location = new System.Drawing.Point(130, 224);
            this.ApplyButton.Name = "ApplyButton";
            this.ApplyButton.Size = new System.Drawing.Size(112, 32);
            this.ApplyButton.TabIndex = 10;
            this.ApplyButton.Text = "Применить";
            this.ApplyButton.UseVisualStyleBackColor = true;
            this.ApplyButton.Click += new System.EventHandler(this.ApplyButton_Click);
            // 
            // ConnectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 268);
            this.Controls.Add(this.ApplyButton);
            this.Controls.Add(this.AutoConnectCheckBox);
            this.Controls.Add(this.SaveDataBaseCheckBox);
            this.Controls.Add(this.IntegratedSecurityCheckBox);
            this.Controls.Add(this.ConnectButton);
            this.Controls.Add(this.DateBaseLabel);
            this.Controls.Add(this.DataBaseTextBox);
            this.Controls.Add(this.ServerLabel);
            this.Controls.Add(this.ServerTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ConnectForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Подключение";
            this.Load += new System.EventHandler(this.ConnectForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ServerTextBox;
        private System.Windows.Forms.Label ServerLabel;
        private System.Windows.Forms.Label DateBaseLabel;
        private System.Windows.Forms.TextBox DataBaseTextBox;
        private System.Windows.Forms.Button ConnectButton;
        private System.Windows.Forms.CheckBox IntegratedSecurityCheckBox;
        private System.Windows.Forms.CheckBox SaveDataBaseCheckBox;
        private System.Windows.Forms.CheckBox AutoConnectCheckBox;
        private System.Windows.Forms.Button ApplyButton;
    }
}
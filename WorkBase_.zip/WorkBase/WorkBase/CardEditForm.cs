﻿using System;
using System.Windows.Forms;

namespace WorkBase
{
    public partial class CardEditForm : Form
    {
       public Cards card = new Cards();
        public CardEditForm(Cards input) // Загрузка данных
        {
            InitializeComponent();
            card = input;
            LastNameText.Text = card.LastName;
            FirstNameText.Text = card.FirstName;
            SurnameText.Text = card.SurName;
            if(card.Gender == "M")
                GenderComboBox.SelectedIndex = 0;
            else if(card.Gender == "W")
                GenderComboBox.SelectedIndex = 1;

            if (card.Bithday != DateTime.MinValue)
                BirthDayPicker.Value = card.Bithday;
            else
                BirthDayPicker.Value = BirthDayPicker.MinDate;

            PhoneHomeText.Text = card.PhoneHome;
            PhoneMobileText.Text = card.PhoneMobile;
            EmailText.Text = card.Email;

            CityText.Text = card.City;
            StreetText.Text = card.Street;
            HouseText.Text = card.House;
            ApartamentText.Text = card.Apartament;

            CardCodeText.Text = card.CardCode;
            if (card.StartDate != DateTime.MinValue)
                StartDatePicker.Value = card.StartDate;
            else
                StartDatePicker.Value = StartDatePicker.MinDate;

            if (card.FinishDate != DateTime.MinValue)
                FinishDatePicker.Value = card.FinishDate;
            else
                FinishDatePicker.Value = FinishDatePicker.MinDate;
        }

        private void BirthDayPicker_ValueChanged(object sender, EventArgs e) // Дата рождения
        {
            if(BirthDayPicker.Value != BirthDayPicker.MinDate)
                card.Bithday = BirthDayPicker.Value;
        }

        private void StartDatePicker_ValueChanged(object sender, EventArgs e) // Дата начало
        {
            if (StartDatePicker.Value != StartDatePicker.MinDate)
                card.StartDate = StartDatePicker.Value;
        }

        private void FinishDatePicker_ValueChanged(object sender, EventArgs e) // Дата Конца
        {
            if (FinishDatePicker.Value != FinishDatePicker.MinDate)
                card.FinishDate = FinishDatePicker.Value;
        }

        private void FirstNameText_TextChanged(object sender, EventArgs e) // Фамилия
        {
            card.FirstName = FirstNameText.Text;
        }

        private void LastNameText_TextChanged(object sender, EventArgs e) // Имя
        {
            card.LastName = LastNameText.Text;
        }

        private void SurnameText_TextChanged(object sender, EventArgs e) // Отчество
        {
            card.SurName= SurnameText.Text;
        }

        private void GenderComboBox_SelectedIndexChanged(object sender, EventArgs e) // Пол
        {
            if (GenderComboBox.SelectedIndex == 0)
                card.Gender = "M";
            else if(GenderComboBox.SelectedIndex == 1)
                card.Gender = "W";

        }

        private void PhoneHomeText_TextChanged(object sender, EventArgs e) // Домашний номер
        {
            card.PhoneHome= PhoneHomeText.Text;
        }

        private void PhoneMobileText_TextChanged(object sender, EventArgs e) // Мобильный номер
        {
            card.PhoneMobile= PhoneMobileText.Text;
        }

        private void EmailText_TextChanged(object sender, EventArgs e) // Почта
        {
            card.Email= EmailText.Text;
        }

        private void CityText_TextChanged(object sender, EventArgs e) // Город
        {
            card.City= CityText.Text;
        }

        private void StreetText_TextChanged(object sender, EventArgs e) // Улица
        {
            card.Street= StreetText.Text;
        }

        private void HouseText_TextChanged(object sender, EventArgs e) // Дом
        {
            card.House= HouseText.Text;
        }

        private void ApartamentText_TextChanged(object sender, EventArgs e) // Апартаменты
        {
            card.Apartament= ApartamentText.Text;
        }

        private void CardCodeText_TextChanged(object sender, EventArgs e) // Номер карты
        {
            card.CardCode= CardCodeText.Text;
        }

        private void CardEditForm_Load(object sender, EventArgs e)
        {

        }

        private void ApplyButton_Click(object sender, EventArgs e) // Кнопка изменить
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

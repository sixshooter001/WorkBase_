﻿namespace WorkBase
{
    partial class ImportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputFileLabel = new System.Windows.Forms.Label();
            this.InputFileText = new System.Windows.Forms.TextBox();
            this.OpenFileButton = new System.Windows.Forms.Button();
            this.ImportButton = new System.Windows.Forms.Button();
            this.UploadCheckBox = new System.Windows.Forms.CheckBox();
            this.ReplaceCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // InputFileLabel
            // 
            this.InputFileLabel.AutoSize = true;
            this.InputFileLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputFileLabel.Location = new System.Drawing.Point(21, 22);
            this.InputFileLabel.Name = "InputFileLabel";
            this.InputFileLabel.Size = new System.Drawing.Size(95, 16);
            this.InputFileLabel.TabIndex = 3;
            this.InputFileLabel.Text = "Путь к файлу";
            // 
            // InputFileText
            // 
            this.InputFileText.BackColor = System.Drawing.Color.White;
            this.InputFileText.Enabled = false;
            this.InputFileText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputFileText.Location = new System.Drawing.Point(12, 41);
            this.InputFileText.Name = "InputFileText";
            this.InputFileText.ReadOnly = true;
            this.InputFileText.Size = new System.Drawing.Size(304, 26);
            this.InputFileText.TabIndex = 2;
            // 
            // OpenFileButton
            // 
            this.OpenFileButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OpenFileButton.Location = new System.Drawing.Point(322, 41);
            this.OpenFileButton.Name = "OpenFileButton";
            this.OpenFileButton.Size = new System.Drawing.Size(47, 26);
            this.OpenFileButton.TabIndex = 4;
            this.OpenFileButton.Text = "...";
            this.OpenFileButton.UseVisualStyleBackColor = true;
            this.OpenFileButton.Click += new System.EventHandler(this.OpenFileButton_Click);
            // 
            // ImportButton
            // 
            this.ImportButton.Enabled = false;
            this.ImportButton.Location = new System.Drawing.Point(12, 145);
            this.ImportButton.Name = "ImportButton";
            this.ImportButton.Size = new System.Drawing.Size(112, 32);
            this.ImportButton.TabIndex = 7;
            this.ImportButton.Text = "Импорт";
            this.ImportButton.UseVisualStyleBackColor = true;
            this.ImportButton.Click += new System.EventHandler(this.ImportButton_Click);
            // 
            // UploadCheckBox
            // 
            this.UploadCheckBox.AutoSize = true;
            this.UploadCheckBox.Checked = true;
            this.UploadCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.UploadCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UploadCheckBox.Location = new System.Drawing.Point(14, 83);
            this.UploadCheckBox.Name = "UploadCheckBox";
            this.UploadCheckBox.Size = new System.Drawing.Size(207, 20);
            this.UploadCheckBox.TabIndex = 8;
            this.UploadCheckBox.Text = "Сразу загрузить на сервер";
            this.UploadCheckBox.UseVisualStyleBackColor = true;
            // 
            // ReplaceCheckBox
            // 
            this.ReplaceCheckBox.AutoSize = true;
            this.ReplaceCheckBox.Checked = true;
            this.ReplaceCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ReplaceCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ReplaceCheckBox.Location = new System.Drawing.Point(14, 109);
            this.ReplaceCheckBox.Name = "ReplaceCheckBox";
            this.ReplaceCheckBox.Size = new System.Drawing.Size(76, 20);
            this.ReplaceCheckBox.TabIndex = 9;
            this.ReplaceCheckBox.Text = "Замена";
            this.ReplaceCheckBox.UseVisualStyleBackColor = true;
            // 
            // ImportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 189);
            this.Controls.Add(this.ReplaceCheckBox);
            this.Controls.Add(this.UploadCheckBox);
            this.Controls.Add(this.ImportButton);
            this.Controls.Add(this.OpenFileButton);
            this.Controls.Add(this.InputFileLabel);
            this.Controls.Add(this.InputFileText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ImportForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Импорт XML";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label InputFileLabel;
        private System.Windows.Forms.TextBox InputFileText;
        private System.Windows.Forms.Button OpenFileButton;
        private System.Windows.Forms.Button ImportButton;
        private System.Windows.Forms.CheckBox UploadCheckBox;
        private System.Windows.Forms.CheckBox ReplaceCheckBox;
    }
}
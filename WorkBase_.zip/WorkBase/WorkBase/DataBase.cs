﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.AxHost;
using System.Windows.Forms;
using System.Data;

namespace WorkBase
{
    static class DataBase
    {
        static SqlConnection connection = new SqlConnection();
        public static void source(string server, string db, bool integratedSecurity = true) // Задать данные подключения 
        {
            connection = new SqlConnection($@"Data Source={server};Initial Catalog={db};Integrated Security={integratedSecurity}");
        }

        public static bool connect() // Подключить 
        {
            try
            {
                connection.Open();
                if (connection.State == System.Data.ConnectionState.Open)
                    return true;
            }
            catch { } // Exeption
            return false;
        }

        public static void close() // Отключить
        {
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
        }

        public static bool state() // Статус
        {
            if (connection.State == System.Data.ConnectionState.Open)
                return true;
            return false;
        }

        public static List<Cards> load() // Загрузить данные с базы
        {
            List<Cards> list = new List<Cards>();
            SqlCommand command = new SqlCommand("Select*From [dbo].[Clients]", connection);
            command.ExecuteNonQuery();

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Cards card = new Cards();
                    card.FirstName= reader[1].ToString();
                    card.LastName = reader[2].ToString();
                    card.SurName = reader[3].ToString();
                    card.Gender = reader[4].ToString();
                    card.Bithday = DateTime.Parse(reader[5].ToString());
                    card.PhoneHome = reader[6].ToString();
                    card.PhoneMobile = reader[7].ToString();
                    card.Email = reader[8].ToString();
                    card.City = reader[9].ToString();
                    card.Street = reader[10].ToString();
                    card.House = reader[11].ToString();
                    card.Apartament = reader[12].ToString();
                    card.CardCode = reader[13].ToString();
                    card.StartDate = DateTime.Parse(reader[14].ToString());
                    card.FinishDate = DateTime.Parse(reader[15].ToString());
                    list.Add(card);

                }

            }
            return list;
        }

        public static void upload(List<Cards> cards, bool replace = true) // Загрузить данные в базу
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                foreach (Cards card in cards)
                {
                    if(card.Update == true)
                    {
                        int card_id = -1;
                        SqlCommand command = new SqlCommand("Select*From [dbo].[Clients] WHERE CARDCODE = @cardcode ", connection);
                        command.Parameters.Add("@cardcode", SqlDbType.NVarChar).Value = card.CardCode;

                        command.ExecuteNonQuery();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if (reader[0] != null)
                                {
                                    card_id = Int32.Parse(reader[0].ToString());
                                }
                            }
                        }
                        if (card_id < 0)
                        {
                            command = new SqlCommand("INSERT INTO [dbo].[Clients] (FIRSTNAME, LASTNAME, SURNAME, GENDER, BIRTHDAY, PHONEHOME, PHONEMOBIL, EMAIL, CITY, STREET, HOUSE, APARTAMENT, CARDCODE, STARTDATE, FINISHDATE) VALUES(@fname,@lname,@sname,@gender,@birthday,@phonehome,@phonemobile,@email,@city,@street,@house,@apartament,@cardcode,@startdate,@finishdate)", connection);
                            command.Parameters.Add("@fname", SqlDbType.NVarChar).Value = card.FirstName;
                            command.Parameters.Add("@lname", SqlDbType.NVarChar).Value = card.LastName;
                            command.Parameters.Add("@sname", SqlDbType.NVarChar).Value = card.SurName;
                            command.Parameters.Add("@gender", SqlDbType.NVarChar).Value = card.Gender;
                            command.Parameters.Add("@birthday", SqlDbType.Date).Value = card.Bithday.Date;
                            command.Parameters.Add("@phonehome", SqlDbType.NVarChar).Value = card.PhoneHome;
                            command.Parameters.Add("@phonemobile", SqlDbType.NVarChar).Value = card.PhoneMobile;
                            command.Parameters.Add("@email", SqlDbType.NVarChar).Value = card.Email;
                            command.Parameters.Add("@city", SqlDbType.NVarChar).Value = card.City;
                            command.Parameters.Add("@street", SqlDbType.NVarChar).Value = card.Street;
                            command.Parameters.Add("@house", SqlDbType.NVarChar).Value = card.House;
                            command.Parameters.Add("@apartament", SqlDbType.NVarChar).Value = card.Apartament;
                            command.Parameters.Add("@cardcode", SqlDbType.NVarChar).Value = card.CardCode;
                            command.Parameters.Add("@startdate", SqlDbType.Date).Value = card.StartDate.Date;
                            command.Parameters.Add("@finishdate", SqlDbType.Date).Value = card.FinishDate.Date;
                            command.ExecuteNonQuery();
                        }
                        else if (card_id > -1 && replace == true)
                        {
                            command = new SqlCommand("UPDATE [dbo].[Clients] SET FIRSTNAME = @fname, LASTNAME = @lname, SURNAME = @sname, GENDER = @gender, BIRTHDAY = @birthday, PHONEHOME = @phonehome, PHONEMOBIL = @phonemobile, EMAIL = @email, CITY = @city, STREET = @street, HOUSE = @house, APARTAMENT = @apartament, CARDCODE = @cardcode, STARTDATE = @startdate, FINISHDATE = @finishdate  WHERE CLIENTID = '" + card_id + "'", connection);
                            command.Parameters.Add("@fname", SqlDbType.NVarChar).Value = card.FirstName;
                            command.Parameters.Add("@lname", SqlDbType.NVarChar).Value = card.LastName;
                            command.Parameters.Add("@sname", SqlDbType.NVarChar).Value = card.SurName;
                            command.Parameters.Add("@gender", SqlDbType.NVarChar).Value = card.Gender;
                            command.Parameters.Add("@birthday", SqlDbType.Date).Value = card.Bithday.Date;
                            command.Parameters.Add("@phonehome", SqlDbType.NVarChar).Value = card.PhoneHome;
                            command.Parameters.Add("@phonemobile", SqlDbType.NVarChar).Value = card.PhoneMobile;
                            command.Parameters.Add("@email", SqlDbType.NVarChar).Value = card.Email;
                            command.Parameters.Add("@city", SqlDbType.NVarChar).Value = card.City;
                            command.Parameters.Add("@street", SqlDbType.NVarChar).Value = card.Street;
                            command.Parameters.Add("@house", SqlDbType.NVarChar).Value = card.House;
                            command.Parameters.Add("@apartament", SqlDbType.NVarChar).Value = card.Apartament;
                            command.Parameters.Add("@cardcode", SqlDbType.NVarChar).Value = card.CardCode;
                            command.Parameters.Add("@startdate", SqlDbType.Date).Value = card.StartDate.Date;
                            command.Parameters.Add("@finishdate", SqlDbType.Date).Value = card.FinishDate.Date;
                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
        }
    }
}
